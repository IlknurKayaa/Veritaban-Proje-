﻿using System;
using Npgsql;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B201210098_Proje_Veritabanı
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Kişiler form2 = new Kişiler();//açılacak form
            form2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Urunler form3 = new Urunler();
            form3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Müşteriler form1 = new Müşteriler();
            form1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Personeller form4 = new Personeller();
            form4.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Tedarikçiler form5 = new Tedarikçiler();
            form5.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Kargo form6 = new Kargo();
            form6.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Faturalar form7 = new Faturalar();
            form7.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Toplamlar form8 = new Toplamlar();
            form8.Show();
        }
    }
}
