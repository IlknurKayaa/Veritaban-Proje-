﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
namespace B201210098_Proje_Veritabanı
{
    public partial class Urunler : Form
    {
        public Urunler()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database= Proje; user Id=postgres; password=i4an0o");
        private void button1_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from urun";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                string query = "select urun.kod,urun.uadi,urun.renk,urun.beden,urun.stok,urun.birim,urun.kat1,urun.kat2 from urun where kod=@p1";
                NpgsqlCommand komut = new NpgsqlCommand(query, baglanti);
                komut.Parameters.AddWithValue("@p1", textBox1.Text);
                komut.ExecuteNonQuery();
                DataTable dt = new DataTable();

                NpgsqlDataAdapter das = new NpgsqlDataAdapter(komut);
                das.Fill(dt);
                dataGridView1.DataSource = dt;
                baglanti.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into urun(kod,uadi,renk,beden,kumaş,stok,birim,kat1,kat2) values(@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9)", baglanti);
            komut1.Parameters.AddWithValue("@p1", textBox1.Text);
            komut1.Parameters.AddWithValue("@p2", textBox2.Text);
            komut1.Parameters.AddWithValue("@p3", textBox3.Text);
            komut1.Parameters.AddWithValue("@p4", textBox4.Text);
            komut1.Parameters.AddWithValue("@p5", textBox5.Text);
            komut1.Parameters.AddWithValue("@p6", numericUpDown1.Value);
            komut1.Parameters.AddWithValue("@p7", float.Parse(textBox7.Text));
            komut1.Parameters.AddWithValue("@p8", comboBox1.SelectedValue.ToString());
            komut1.Parameters.AddWithValue("@p9", comboBox2.SelectedValue.ToString());
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme işlemi tamamlandı.");
        }

        private void Urunler_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlDataAdapter da = new NpgsqlDataAdapter("select * from kategori1", baglanti);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox1.DisplayMember = "tip1";
            comboBox1.ValueMember = "tip1";
            comboBox1.DataSource = dt;
            baglanti.Close();

            baglanti.Open();
            NpgsqlDataAdapter dat = new NpgsqlDataAdapter("select * from kategori2", baglanti);
            DataTable dtt = new DataTable();
            dat.Fill(dtt);
            comboBox2.DisplayMember = "tip2";
            comboBox2.ValueMember = "tip2";
            comboBox2.DataSource = dtt;
            baglanti.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut2 = new NpgsqlCommand("Delete from urun where kod=@p1", baglanti);
            komut2.Parameters.AddWithValue("@p1", textBox1.Text);
            komut2.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Silme işlemi tamamlansın mı?.","Bilgi",MessageBoxButtons.YesNo,MessageBoxIcon.Stop);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update urun set uadi=@p1,stok=@p2,birim=@p3 where kod=@p4", baglanti);
            komut3.Parameters.AddWithValue("@p1", textBox2.Text);
            komut3.Parameters.AddWithValue("@p2", numericUpDown1.Value);
            komut3.Parameters.AddWithValue("@p3", float.Parse(textBox7.Text));
            komut3.Parameters.AddWithValue("@p4", textBox1.Text);
            komut3.ExecuteNonQuery();
            MessageBox.Show("Güncelleme işlemi tamamlandı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            baglanti.Close();
        }
    }
}
