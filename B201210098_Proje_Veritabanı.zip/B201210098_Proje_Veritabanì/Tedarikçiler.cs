﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
namespace B201210098_Proje_Veritabanı
{
    public partial class Tedarikçiler : Form
    {
        public Tedarikçiler()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database= Proje; user Id=postgres; password=i4an0o");
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                string query = "select  kısı.kısıkodu,kısı.ad,    kısı.soyad,   kısı.kısıtipi,  tedarikci.sirket,  tedarikci.alimtarih from    kısı inner join tedarikci  ON kısı.kısıkodu = tedarikci.kısıkodu";
                NpgsqlCommand komut1 = new NpgsqlCommand(query, baglanti);
                komut1.ExecuteNonQuery();
                DataTable dt = new DataTable();

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(komut1);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                baglanti.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            

        }
    }
}
